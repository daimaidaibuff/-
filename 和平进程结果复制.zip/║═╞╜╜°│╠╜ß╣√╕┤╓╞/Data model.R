model <- glm(ceasefire ~ religion + ideology +ethnic + Pol_Gov.count + Soc_Infra.count+ mediation.avg +
               v2x_polyarchy + v2csprtcpt + v2x_liberal+ Econ_IllegalNet.count, data = qsi1 )
summary(model)

model1 <- glm(ceasefire ~  Pol_Gov.count  , data = qsi1 )
summary(model1)

model2 <- glm(ceasefire ~  Pol_Gov.count  +
               v2x_polyarchy+ mediation.avg , data = qsi1 )
summary(model2)

model3 <- glm(ceasefire ~  Pol_Gov.count  +
               v2x_polyarchy + mediation.avg+ v2csprtcpt + v2x_liberal+ Econ_IllegalNet.count, data = qsi1 )
summary(model3)

model4 <- glm(ceasefire ~  Pol_Gov.count +  v2x_polyarchy +mediation.avg+ + v2csprtcpt +   
                v2x_liberal+ Econ_IllegalNet.count +Soc_Infra.count + religion + ideology +ethnic
             , data = qsi1 )
summary(model4)

library(stargazer)
stargazer( model1, model2, model3, model4, type = "text")

------------------

model10 <- glm(agreement ~ religion + ideology +ethnic + Pol_Gov.count + Soc_Infra.count+ mediation.avg +
                 v2x_polyarchy + v2csprtcpt + v2x_liberal+ Econ_IllegalNet.count, data = qsi1 )
summary(model10)

model11 <- glm(agreement ~  Pol_Gov.count  , data = qsi1 )
summary(model11)

model12 <- glm(agreement ~  Pol_Gov.count  +
                v2x_polyarchy+ mediation.avg , data = qsi1 )
summary(model12)

model13 <- glm(agreement ~  Pol_Gov.count  +
                v2x_polyarchy + mediation.avg+ v2csprtcpt + v2x_liberal+ Econ_IllegalNet.count, data = qsi1 )
summary(model13)

model14 <- glm(agreement ~  Pol_Gov.count +  v2x_polyarchy +mediation.avg+ + v2csprtcpt +   
                v2x_liberal+ Econ_IllegalNet.count +Soc_Infra.count + religion + ideology +ethnic
              , data = qsi1 )
summary(model14)

model15 <- glm(agreement ~  Pol_Gov.count + Pol_Gov.count*mediation.avg+ v2x_polyarchy +mediation.avg+ + v2csprtcpt +   
                 v2x_liberal+ Econ_IllegalNet.count +Soc_Infra.count + religion + ideology +ethnic
               , data = qsi1 )
summary(model15)


library(stargazer)

stargazer( model11, model12, model13, model14,model15, type = "text")

